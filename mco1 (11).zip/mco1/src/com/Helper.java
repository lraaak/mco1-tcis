
package com;

import java.util.*;

public class Helper {
    

    public static Cards findCard (String name, ArrayList<Cards> cards) {
        for (Cards card : cards) {
            if (card.getName().equalsIgnoreCase(name)) {
                return card; // returns the card object found
            }
        }
        return null; 
    }

    public static boolean isCardConflicting(ArrayList<Cards> cards, String name, String rarity, String variant, double baseValue) {
    for (Cards card : cards) {

        if (card.getName().equalsIgnoreCase(name) && 
            (!card.getRarity().equals(rarity) || !card.getVariant().equals(variant) || card.getBaseValue() != baseValue)) {

            return true;
        }
    }
    return false;
    }

    public static boolean isValidRarity(String rarity){
        return rarity.equals("COMMON") || rarity.equals("UNCOMMON") || rarity.equals("RARE") || rarity.equals("LEGENDARY");
    }

    public static boolean isValidVariant(String variant){
        return variant.equals("NORMAL") || variant.equals("EXTENDED-ART") ||
        variant.equals("FULL-ART") || variant.equals("ALT-ART");
    }



    public static Binders findBinder(String name, ArrayList<Binders> binders){
        for (Binders binder : binders){
            if (binder.getName().equalsIgnoreCase(name)){
                return binder;
            }
        }
        return null;
    }

    public static Decks findDecks(String name, ArrayList<Decks> decks) {
        for (Decks deck : decks) {
            if (deck.getName().equalsIgnoreCase(name)) {
                return deck; // returns the deck object found
            }
        }
        return null; 
    }

    public static void displayAlphabetically(ArrayList<Cards> cards) {     
        ArrayList<Cards> sortedCards = new ArrayList<>(cards);

        Collections.sort(sortedCards, (c1, c2) -> c1.getName().compareToIgnoreCase(c2.getName()));  // sort alphabetically
        System.out.println("Cards:");
        for (Cards c : sortedCards) {
            System.out.println("Name: " + c.getName() + " | Count: " + c.getSelfCount());
        }
    }

    public static boolean confirmAction() {
        Scanner sc = new Scanner(System.in);
        String answer;

        while (true) {
            System.out.print("Are you sure with your action? (yes/no): ");
            answer = sc.nextLine();

            if (answer.equalsIgnoreCase("yes")) {
                return true;
            } else if (answer.equalsIgnoreCase("no")) {
                return false;
            } else {
                System.out.println("Invalid choice. Please enter 'yes' or 'no'.");
            }
        }
    }

    public static Cards generateCard(Scanner sc) {
    
        String name = getInput(sc,"Enter Card Name or 'EXIT' to cancel:");
        if (name == null) {
            return null;  
        }

        
        String rarity = getValidRarity(sc);
        if (rarity == null) {
            return null;  
        }

        
        String variant = "NORMAL";  
        if (rarity.equals("RARE") || rarity.equals("LEGENDARY")) {
            variant = getValidVariant(sc);
            if (variant == null) {
                return null;  
            }
        }

        double value = getValidValue(sc);
        if (value == 0) {
            return null;  
        }

        Cards newCard = new Cards(name, rarity, variant, value);
        System.out.println("Card generated: " + newCard.getName());
        return newCard;
    }

    public static String getInput(Scanner sc, String prompt) {
        System.out.print(prompt);
        String input = sc.nextLine().trim().toUpperCase();
        if (input.equalsIgnoreCase("EXIT")) {
            System.out.println("Exiting");
            return null;
        }
        return input;
    }

    public static String getValidRarity(Scanner sc) {
        String rarity;
        do {
            rarity = getInput(sc, "Enter Rarity (COMMON, UNCOMMON, RARE, LEGENDARY) or 'EXIT' to cancel: ");
            if (rarity == null) 
                return null;
            if (!isValidRarity(rarity.toUpperCase())) {
                System.out.println("Invalid rarity. Please enter one of the following: COMMON, UNCOMMON, RARE, LEGENDARY.");
            }
        } while (!isValidRarity(rarity));

        return rarity.toUpperCase();
    }

    public static String getValidVariant(Scanner sc) {
        String variant;
        do {
            variant = getInput(sc, "Enter Variant (for RARE and LEGENDARY only) or 'EXIT' to cancel: ");
            if (variant == null) return null;
            if (!isValidVariant(variant.toUpperCase())) {
                System.out.println("Invalid variant. For RARE and LEGENDARY cards, valid variants are NORMAL, EXTENDED-ART, FULL-ART, ALT-ART.");
            }
        } while (!isValidVariant(variant.toUpperCase()));

        return variant.toUpperCase();
    }

    public static double getValidValue(Scanner sc) {
        double value = 0;
        do {
            System.out.print("Enter Value (dollar value) or 'EXIT' to cancel: ");
            if (sc.hasNextDouble()) {
                value = sc.nextDouble();
                if (value <= 0) {
                    System.out.println("Value must be greater than zero. Please enter a valid value.");
                }
            } else {
                String input = sc.nextLine();
                if (input.equalsIgnoreCase("EXIT")) {
                    System.out.println("Card input cancelled.");
                    return 0;
                }
                System.out.println("Invalid input! Please enter a valid dollar value.");
            }
        } while (value <= 0);
        return value;
    }

    public static void addingCard(Collection collection, String name, String rarity, String variant, double value) {
        if (isCardConflicting(collection.getCard(), name, rarity, variant, value)) {
            System.out.println("A card with the same name but different details already exists.");
            System.out.println("Card input canceled.");
        } else {
            collection.addCard(name, rarity, variant, value);
            System.out.println("Card added.");
        }
    }

    public static int findIndex(Cards card, ArrayList<Cards> cards){
        for (int i = 0; i < cards.size(); i++){
            if (card == cards.get(i)){
                return i;
            }
        }
        return -1;
    }
}
