package com;
import java.util.*;

public class TCIS {
    Scanner sc = new Scanner (System.in);
    private ArrayList<Decks> decks;
    private ArrayList<Binders> binders;
    private Collection collection;

    public TCIS(){
        this.decks = new ArrayList<>();
        this.binders = new ArrayList<>();
        this.collection = new Collection();
    }

    public void createDeck(String name){
        
        if(Helper.findDecks(name, decks)== null ){
        Decks newDeck = new Decks(name);

        decks.add(newDeck);
        }
        else {
            System.out.println("Deck already exists");
        }
    }

    public void createBinder(String name){
        if (Helper.findBinder(name, binders)== null ){
            Binders newBinder = new Binders(name);

            binders.add(newBinder);
        }
        else {
            System.out.println("Binders already exists");
        }
    }

    public void deleteDeck (Decks deck){

       for (Cards card : deck.getCard()){
            card.increaseCount();
            Collection.increaseTotalCount();
       }

       decks.remove(deck);
       Decks.decreaseDeckCount();
       System.out.println("Deck has been deleted");

    }

    public void deleteBinder (Binders binder){

        for (Cards card : binder.getCard()){
            Collection.addCard(card.getName(), card.getRarity(), card.getVariant(), card.getBaseValue());
            Collection.increaseTotalCount();
        }

        binders.remove(binder);
        Binders.decreaseBinderCount();
        System.out.println("Binder has been deleted");
       
    }

    public void viewBinders() {
    System.out.println("=== BINDERS LIST ===");

    if (binders.isEmpty()) {
        System.out.println("No binders available.");
        return;
    }

    System.out.println("╔═════╦════════════════════════╗");
    System.out.println("║ No. ║ Binder Name            ║");
    System.out.println("╠═════╬════════════════════════╣");

    for (int i = 0; i < binders.size(); i++) {
        System.out.printf("║ %-3d ║ %-22s ║%n", i + 1, binders.get(i).getName());
    }

    System.out.println("╚═════╩════════════════════════╝");

    }
    
    public void viewDecks() {
    System.out.println("=== DECKS LIST ===");

    if (decks.isEmpty()) {
        System.out.println("No decks available.");
        return;
    }

    System.out.println("╔═════╦════════════════════════╗");
    System.out.println("║ No. ║ Deck Name              ║");
    System.out.println("╠═════╬════════════════════════╣");

    for (int i = 0; i < decks.size(); i++) {
        System.out.printf("║ %-3d ║ %-22s ║%n", i + 1, decks.get(i).getName());
    }

    System.out.println("╚═════╩════════════════════════╝");
}


 public void displayMenu() {
    System.out.println("Welcome to the TCIS");

    int userChoice;
    do {
        System.out.println("=== Trading Card Inventory System (TCIS) ===");
        System.out.println("[0] - Exit");
        System.out.println("[1] - Add Card");
        System.out.println("[2] - Add Deck");
        System.out.println("[3] - Add Binder");
        System.out.println("[4] - View Collection");

        int option = 5;
        boolean existingBinder = false;
        boolean existingDeck = false;

        if (Binders.getTotalBinders() > 0) {
            existingBinder = true;
            System.out.println("[" + option + "] - Manage Binder");
            option++;
        }
        if (Decks.getTotalDeck() > 0) {
            existingDeck = true;
            System.out.println("[" + option + "] - Manage Decks");
            option++;
        }

        System.out.print("Select an option: ");
        userChoice = sc.nextInt();
        sc.nextLine();

        if (userChoice == 1) {
            Cards newCard = Helper.generateCard(sc);
            if (newCard != null) {
                collection.addCard(newCard.getName(), newCard.getRarity(), newCard.getVariant(), newCard.getBaseValue());
                System.out.println("Card successfully added or updated.");
            } else {
                System.out.println("Card input canceled.");
            }
        } else if (userChoice == 2) {
            System.out.print("Name:");
            String name = sc.nextLine();
            createDeck(name);
        } else if (userChoice == 3) {
            System.out.print("Name:");
            String name = sc.nextLine();
            createBinder(name);
        } else if (userChoice == 4) {
            collection.displayAllCards();
            if (!collection.getCard().isEmpty()){
                System.out.print("Enter card name to view details and EXIT to go back:");
                String cardName;
                do {
                    cardName = sc.nextLine();
                    Cards card = Helper.findCard(cardName, collection.getCard());

                    if (card != null) {
                        Collection.displayCardDetails(card.getName());
                        System.out.println("Enter another card name or EXIT to go back");
                    }else if (card == null && !cardName.equalsIgnoreCase("exit")){
                        System.out.println("Card not found");
                    }
                } while (!cardName.equalsIgnoreCase("exit"));
            }
        } else if (userChoice == 5 && existingBinder) {
            String name;
            do {
                viewBinders();
                System.out.print("Enter binder name or EXIT to go back:");
                name = sc.nextLine();
                Binders binder = Helper.findBinder(name, binders);
                if (binder != null) {
                    int binderChoice;
                    do {
                        System.out.println("Binder: " + binder.getName());
                        System.out.println("╔══════════════════════════════╗");
                        System.out.println("║ [0] Exit                     ║");
                        System.out.println("║ [1] Add Card                 ║");
                        System.out.println("║ [2] Remove Card              ║");
                        System.out.println("║ [3] View Cards               ║");
                        System.out.println("║ [4] Trade                    ║");
                        System.out.println("║ [5] Delete Binder            ║");
                        System.out.println("╚══════════════════════════════╝");
                        binderChoice = sc.nextInt();
                        sc.nextLine();

                        switch (binderChoice) {
                            case 1:
                                collection.displayAllCards();
                                String cardName = sc.nextLine();
                                Cards cardToAdd = Helper.findCard(cardName, collection.getCard());

                                if (cardToAdd != null) {
                                    binder.addCard(cardToAdd);
                                } else {
                                    System.out.println("Card is not found");
                                }
                                break;

                            case 2:
                                binder.displayBinder();
                                if (!binder.getCard().isEmpty()) {
                                    String binderCard = sc.nextLine();
                                    Cards cardToRemove = Helper.findCard(binderCard, binder.getCard());

                                    if (cardToRemove != null) {
                                        binder.removeCard(cardToRemove);
                                        System.out.println("Card has been removed");
                                    } else {
                                        System.out.println("Card is not found");
                                    }
                                }
                                break;

                            case 3:
                                binder.displayBinder();
                                break;

                            case 4:
                                binder.displayBinder();
                                System.out.print("Enter card name:");
                                String card = sc.nextLine();
                                Cards ownCard = Helper.findCard(card, binder.getCard());
                                if (ownCard!= null){
                                    System.out.println("Please input details of incoming card");
                                    Cards incomingCard = Helper.generateCard(sc);
                                    if (incomingCard != null){
                                       int cardIndex = Helper.findIndex(ownCard, binder.getCard());
                                        binder.tradeCards(ownCard, incomingCard, cardIndex);
                                    }else{
                                        System.out.println("Trade was not successful");
                                    }
                                }else{
                                    System.out.println("Card is not found");
                                }
                                sc.nextLine();
                                break;

                            case 5:
                                String answer;
                                boolean isDone = false;
                                do {
                                    System.out.println("Are you sure you want to delete " + binder.getName() + "?");

                                    answer = sc.nextLine();

                                    if (answer.equalsIgnoreCase("yes")) {
                                        deleteBinder(binder);
                                        System.out.println("Cards have been returned to the collection");
                                        isDone = true;
                                        binderChoice = 0;
                                        name = "EXIT";
                                    } else if (answer.equalsIgnoreCase("no")) {
                                        isDone = true;
                                    } else {
                                        System.out.println("Invalid input");
                                    }
                                } while (!isDone);
                                break;

                            case 0:
                                System.out.println("Exiting");

                            default:
                                System.out.println("Invalid choice");
                        }
                    } while (binderChoice != 0);
                } else if (name.equalsIgnoreCase("exit") && binder == null) {
                    System.out.println("Binder not found");
                }
            } while (!name.equalsIgnoreCase("EXIT"));
        } else if ((userChoice == 5 && existingDeck) || userChoice == 6 && existingDeck) {
            String name;
            do {
                viewDecks();
                System.out.print("Enter deck name or EXIT to go back:");
                name = sc.nextLine();
                Decks deck = Helper.findDecks(name, decks);
                if (deck != null) {
                    int deckChoice;
                    do {
                        System.out.println("Deck: " + deck.getName());
                        System.out.println("╔══════════════════════════════╗");
                        System.out.println("║ [0] Exit                     ║");
                        System.out.println("║ [1] Add Card                 ║");
                        System.out.println("║ [2] Remove Card              ║");
                        System.out.println("║ [3] View Cards               ║");
                        System.out.println("║ [4] Delete Deck              ║");
                        System.out.println("╚══════════════════════════════╝");
                        deckChoice = sc.nextInt();
                        sc.nextLine();

                        switch (deckChoice) {
                            case 1:
                                collection.displayAllCards();
                                if (!collection.getCard().isEmpty()){
                                String deckCard = sc.nextLine();
                                Cards cardToAdd = Helper.findCard(deckCard, collection.getCard());

                                if (cardToAdd != null) {
                                    deck.addCard(cardToAdd);
                                    System.out.println("Card has been added");
                                } else {
                                    System.out.println("Card is not found");
                                }
                                }else {
                                    System.out.println("Collection is empty");
                                }
                                break;

                            case 2:
                                deck.displayDeck();
                                if (deck.getTotalCard() > 0) {
                                    String binderCard = sc.nextLine();
                                    Cards cardToRemove = Helper.findCard(binderCard, deck.getCard());

                                    if (cardToRemove != null) {
                                        deck.removeCard(cardToRemove);
                                    } else {
                                        System.out.println("Card is not found");
                                    }
                                }
                                break;

                            case 3:
                                deck.displayDeck();
                                break;

                            case 4:
                                String answer;
                                boolean isDone = false;
                                do {
                                    System.out.println("Are you sure you want to delete " + deck.getName() + "?");

                                    answer = sc.nextLine();

                                    if (answer.equalsIgnoreCase("yes")) {
                                        deleteDeck(deck);
                                        isDone = true;
                                        deckChoice = 0;
                                        name = "EXIT";
                                    } else if (answer.equalsIgnoreCase("no")) {
                                        isDone = true;
                                    } else {
                                        System.out.println("Invalid input");
                                    }
                                } while (!isDone);
                                break;

                            case 0:
                                System.out.println("Exiting");
                                break;

                            default:
                                System.out.println("Invalid choice");
                        }
                    } while (deckChoice != 0);
                } else if (!name.equalsIgnoreCase("exit") && deck == null) {
                    System.out.println("Deck is not found");
                }
            } while (!name.equalsIgnoreCase("EXIT"));
        } else if (userChoice == 0) {
            System.out.println("Exiting");
        } else {
            System.out.println("Invalid input");
        }
    } while (userChoice != 0);
  }
}


