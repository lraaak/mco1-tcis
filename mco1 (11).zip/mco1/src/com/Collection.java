package com;

import java.util.*;


public class Collection {
    private static ArrayList<Cards> cards;
    private static int totalCount = 0;

    public Collection(){
        Collection.cards = new ArrayList<>();
    }

    public static void addCard(String name, String rarity, String variant, double baseValue) {
    
        Cards existingCard = Helper.findCard(name, cards);

        if (existingCard == null) {
                Cards newCard = new Cards(name, rarity, variant, baseValue);
                cards.add(newCard);
                increaseTotalCount();
            } else {
                    existingCard.increaseCount();
                    increaseTotalCount();
                    System.out.println("Card count increased: " + existingCard.getName() + ".");
                }
            }
        


    public static void removeCard(String name){
        Cards foundCard = Helper.findCard(name, cards);
        if (foundCard != null) {
            if (foundCard.getSelfCount() > 1){
                foundCard.decreaseCount();
                decreaseTotalCount();
                System.out.println("Card count decreased. New Count: " + foundCard.getSelfCount());
            }
            else {
                cards.remove(foundCard);
                decreaseTotalCount();
                System.out.println("Card removed from collection: " + foundCard.getName());
            }
        } else {
            System.out.println("Card not found in collection.");
        }
    }

    public static void displayCardDetails(String name){
        Cards foundCard = Helper.findCard(name, cards);
        if (foundCard != null) {
            System.out.println("====== Card Details ======");
            System.out.println("Name    : " + foundCard.getName());
            System.out.println("Rarity  : " + foundCard.getRarity());
            System.out.println("Variant : " + foundCard.getVariant());
            System.out.println("Value   : $" + String.format("%.2f", foundCard.getFinalValue()));
            System.out.println("Count   : " + foundCard.getSelfCount());
            System.out.println("==========================");
        } else {
            System.out.println("Card not found in collection.");
        }
    }
    
    public void displayAllCards() {

        if (cards.isEmpty()) {
            System.out.println("No cards in collection.");
        } else {
            Helper.displayAlphabetically(cards); 
        }
}


    public static void increaseTotalCount() {
        totalCount++;
    }

    public static void decreaseTotalCount() {
        if (totalCount > 0) 
            totalCount--;
    }
    

    public ArrayList<Cards> getCard() {
        return cards;
    }

    public static int getTotalCount() {
        return totalCount;
    }
}