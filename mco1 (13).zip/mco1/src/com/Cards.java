package com;

// TODO: NEED TO ADD VALID CHECKERS WHEN USER INPUTS STUFF IN CLI (CODE WHEN WE'RE IN MAIN OR TCIS CLASS NA)

public class Cards {
    private String name;
    private String rarity;
    private String variant; 
    private final double baseValue;
    private double finalValue;
    private int self_count; // count of the card in the collection
    

    public Cards(String name, String rarity, String variant, double baseValue) {
        this.name = name;

        
        if (Helper.isValidRarity(rarity)) {
            this.rarity = rarity.toUpperCase();
        } else {
            this.rarity = "COMMON";  // default value is COMMON if invalid rarity is provided
        }

        
        if (this.rarity.equals("COMMON") || this.rarity.equals("UNCOMMON")) {
            this.variant = "NORMAL";
        } else {
            
            if (Helper.isValidVariant(variant)) {
                this.variant = variant.toUpperCase();
            } else {
                this.variant = "NORMAL";  
            }
        }

        this.baseValue = baseValue;
        this.finalValue = calculateValue(baseValue, this.variant);
        this.self_count = 1;  
    }

        

        public double calculateValue(double baseValue, String variant){
            return switch (variant) {
                case "EXTENDED-ART" -> baseValue * 1.50;
                case "FULL-ART" -> baseValue * 2.0;
                case "ALT-ART" -> baseValue * 3.0;
                default -> baseValue;
            };
        }

        public void increaseCount(){
            this.self_count++;
        }

        public void decreaseCount(){
            if (self_count > 0) {
                this.self_count--;
            }
            else
                System.out.println("You cannot decrease the count of a card that is already at 0.");
        }

        public String getName(){
            return this.name;
        }

        public String getRarity(){
            return this.rarity;
        }

        public String getVariant(){
            return this.variant;
        }

    public void setName(String name) {
        this.name = name;
    }

    public void setRarity(String rarity) {
        this.rarity = rarity;
    }

    public void setVariant(String variant) {
        this.variant = variant;
    }

    public double getFinalValue(){
        return this.finalValue;
    }

    public void setFinalValue(double finalValue){
        this.finalValue = finalValue;
    }

    public double getBaseValue() {
        return baseValue;
    }

    public int getSelfCount() {
            return self_count;
    }

}
