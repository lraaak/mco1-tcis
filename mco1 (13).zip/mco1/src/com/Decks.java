package com;
import java.util.*;

// TODO: NEED TO ADD DELETE DECK

public class Decks{
    private String name;
    private ArrayList<Cards> cards;
    private static int totalDeck = 0;

    public Decks (String name){
        this.cards = new ArrayList<>();
        this.name = name;
        totalDeck++;
    }
    // modify
    public void addCard(Cards card){
        if (Helper.findCard(card.getName(), this.cards) == null){
            if (getTotalCard() < 10){
                this.cards.add(card);
                Collection.removeCard(card.getName());  
                System.out.println("Card has been added"); 
            }
            else {
                System.out.println("Deck is full");
            }
        }
        else{
            System.out.println("Duplicates are not allowed");
        }
    }
    
    // modify
    public void removeCard(Cards card){
        if (Helper.findCard(card.getName(),this.cards) != null){
           if (getTotalCard() > 0){
            this.cards.remove(card);
            Collection.addCard(card.getName(), card.getRarity(), card.getVariant(), card.getBaseValue());
            }
            else   {
            System.out.println("Deck is empty");
            }
        } 
        else {
            System.out.println("Card is not found");
        }
    }

    public static void decreaseDeckCount(){
        totalDeck--;
    }

    public void displayDeck(){
        if (cards.isEmpty()){
            System.out.println("Deck is empty");
        } else {
            System.out.println("Deck Name: " + name);
            System.out.println("Total Cards: " + getTotalCard());
            for (int i = 0; i < cards.size(); i++) {
                Cards card = cards.get(i);
                System.out.println((i + 1) + ". Card Name: " + card.getName());
            }
        }
    }

    public void displayCardDetails(int index) {
        if (index < 1 || index > cards.size()) {
            System.out.println("Invalid card number.");
            return;
        }

        Cards card = cards.get(index - 1);
        System.out.println("Card Name: " + card.getName());
        System.out.println("Rarity: " + card.getRarity());
        System.out.println("Variant: " + card.getVariant());
        System.out.println("Value: " + card.getFinalValue());
        System.out.println("Count in Collection: " + card.getSelfCount());
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Cards> getCard() {
        return cards;
    }

    public int getTotalCard(){
        return cards.size();
    }

    public static int getTotalDeck() {
        return totalDeck;
    }
}
