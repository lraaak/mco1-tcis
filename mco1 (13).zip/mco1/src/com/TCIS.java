package com;
import java.util.*;

public class TCIS {
    Scanner sc = new Scanner (System.in);
    private ArrayList<Decks> decks;
    private ArrayList<Binders> binders;
    private Collection collection;

    public TCIS(){
        this.decks = new ArrayList<>();
        this.binders = new ArrayList<>();
        this.collection = new Collection();
    }

    public void createDeck(String name){
        
        if(Helper.findDecks(name, decks)== null ){
        Decks newDeck = new Decks(name);

        decks.add(newDeck);
        System.out.println("Deck has been created");
        }
        else {
            System.out.println("Deck already exists");
        }
    }

    public void createBinder(String name){
        if (Helper.findBinder(name, binders)== null ){
            Binders newBinder = new Binders(name);

            binders.add(newBinder);
            System.out.println("Binder has been created");
        }
        else {
            System.out.println("Binder already exists");
        }
    }

    public void deleteDeck (Decks deck){

        System.out.println("Deck has been deleted");
        for (Cards card : deck.getCard()){
            Collection.addCard(card.getName(), card.getRarity(), card.getVariant(), card.getBaseValue());
            Collection.increaseTotalCount();
       }

        decks.remove(deck);
        Decks.decreaseDeckCount();

    }

    public void deleteBinder (Binders binder){

        System.out.println("Binder has been deleted");
        for (Cards card : binder.getCard()){
            Collection.addCard(card.getName(), card.getRarity(), card.getVariant(), card.getBaseValue());
            Collection.increaseTotalCount();
        }

        binders.remove(binder);
        Binders.decreaseBinderCount();
       
    }

    public void viewBinders() {
    System.out.println("=== BINDERS LIST ===");

    if (binders.isEmpty()) {
        System.out.println("No binders available.");
        return;
    }

    System.out.println("╔═════╦════════════════════════╗");
    System.out.println("║ No. ║ Binder Name            ║");
    System.out.println("╠═════╬════════════════════════╣");

    for (int i = 0; i < binders.size(); i++) {
        System.out.printf("║ %-3d ║ %-22s ║%n", i + 1, binders.get(i).getName());
    }

    System.out.println("╚═════╩════════════════════════╝");

    }
    
    public void viewDecks() {

    if (decks.isEmpty()) {
        System.out.println("No decks available.");
        return;
    }

    System.out.println("╔═════╦════════════════════════╗");
    System.out.println("║ No. ║ Deck Name              ║");
    System.out.println("╠═════╬════════════════════════╣");

    for (int i = 0; i < decks.size(); i++) {
        System.out.printf("║ %-3d ║ %-22s ║%n", i + 1, decks.get(i).getName());
    }

    System.out.println("╚═════╩════════════════════════╝");
}


 public void displayMenu() {
    System.out.println("Welcome to the TCIS");

    int userChoice;
    do {
        System.out.println("=== Trading Card Inventory System (TCIS) ===");
        System.out.println("[0] - Exit");
        System.out.println("[1] - Add Card");
        System.out.println("[2] - Add Deck");
        System.out.println("[3] - Add Binder");
        System.out.println("[4] - View Collection");

        int option = 5;
        boolean existingBinder = false;
        boolean existingDeck = false;

        if (Binders.getTotalBinders() > 0) {
            existingBinder = true;
            System.out.println("[" + option + "] - Manage Binder");
            option++;
        }
        if (Decks.getTotalDeck() > 0) {
            existingDeck = true;
            System.out.println("[" + option + "] - Manage Decks");
            option++;
        }
        System.out.println("============================================");

        System.out.print("Select an option:");
        userChoice = sc.nextInt();
        sc.nextLine();

        if (userChoice == 1) {
            Cards newCard = Helper.generateCard(sc);
            if (newCard != null) {
                Helper.addingCard(collection, newCard.getName(), newCard.getRarity(), newCard.getVariant(), newCard.getBaseValue());
            } else {
                System.out.println("Card input cancelled.");
            }
        } else if (userChoice == 2) {
            System.out.print("Name:");
            String name = sc.nextLine();
            if (Helper.confirmAction()){
            createDeck(name);
            }
        } else if (userChoice == 3) {
            System.out.print("Name:");
            String name = sc.nextLine();
            if (Helper.confirmAction()){
            createBinder(name);
            }
        } else if (userChoice == 4) {
            if (!collection.getCard().isEmpty()){
                String cardName;
                do {
                    collection.displayAllCards();
                    System.out.print("Enter card name to view details and EXIT to go back:");
                    cardName = sc.nextLine();
                    Cards card = Helper.findCard(cardName, collection.getCard());
                    if (card != null){
                        int choice;
                        do {
                        System.out.println("╔══════════════════════════════╗");
                        System.out.println("║ [0] Back to Collection       ║");
                        System.out.println("║ [1] View Details             ║");
                        System.out.println("║ [2] Increase Count           ║");
                        System.out.println("║ [3] Decrease Count           ║");
                        System.out.println("║ [4] Return to Menu           ║");
                        System.out.println("╚══════════════════════════════╝");
                        System.out.print("Enter choice:");
                        choice = sc.nextInt();
                        sc.nextLine();
                            switch(choice){
                                case 1:
                                    Helper.displayCardDetails(card.getName(), collection.getCard());
                                    break;
                                case 2:
                                    if (Helper.confirmAction()){
                                    collection.addCardCount(card.getName());
                                    System.out.println("Card count has been increased");
                                    }
                                    break;
                                case 3:
                                    if (Helper.confirmAction()){
                                    collection.decreaseCardCount(card.getName());
                                    System.out.println("Card count has been decreased");
                                    }
                                    break;
                                case 4:
                                    choice = 0;
                                    cardName = "exit";
                                    break;
                                case 0:
                                    break;
                                default:
                                    System.out.println("Invalid choice");
                            }
                        }while(choice != 0 && !collection.getCard().isEmpty());
                    }else if (card == null && !cardName.equalsIgnoreCase("exit") && !collection.getCard().isEmpty()){
                        System.out.println("Card not found");
                    }
                }while (!cardName.equalsIgnoreCase("exit") && !collection.getCard().isEmpty());
            }else{
                System.out.println("Collection is empty");
            }
        }else if (userChoice == 5 && existingBinder) {
            String name;
            do {
                viewBinders();
                System.out.print("Enter binder name or EXIT to go back:");
                name = sc.nextLine();
                Binders binder = Helper.findBinder(name, binders);
                if (binder != null) {
                    int binderChoice;
                    do {
                        System.out.println("Binder: " + binder.getName());
                        System.out.println("╔══════════════════════════════╗");
                        System.out.println("║ [0] Exit                     ║");
                        System.out.println("║ [1] Add Card                 ║");
                        System.out.println("║ [2] Remove Card              ║");
                        System.out.println("║ [3] View Cards               ║");
                        System.out.println("║ [4] Trade                    ║");
                        System.out.println("║ [5] Delete Binder            ║");
                        System.out.println("║ [6] Return to menu           ║");
                        System.out.println("╚══════════════════════════════╝");
                        System.out.print("Enter choice:");
                        binderChoice = sc.nextInt();
                        sc.nextLine();

                        switch (binderChoice) {
                            case 1:
                                collection.displayAllCards();
                                if (!collection.getCard().isEmpty()){
                                String cardName = sc.nextLine();
                                Cards cardToAdd = Helper.findCard(cardName, collection.getCard());

                                if (cardToAdd != null) {
                                    if (Helper.confirmAction()){
                                    binder.addCard(cardToAdd);
                                    }
                                }else{
                                    System.out.println("Card is not found");
                                }
                                }
                                break;
                            case 2:
                                binder.displayBinder();
                                if (!binder.getCard().isEmpty()) {
                                    String binderCard = sc.nextLine();
                                    Cards cardToRemove = Helper.findCard(binderCard, binder.getCard());

                                    if (cardToRemove != null) {
                                        binder.removeCard(cardToRemove);
                                        System.out.println("Card has been removed");
                                    } else {
                                        System.out.println("Card is not found");
                                    }
                                }
                                break;

                            case 3:
                                binder.displayBinder();
                                break;

                            case 4:
                                binder.displayBinder();
                                System.out.print("Enter card name:");
                                String card = sc.nextLine();
                                Cards ownCard = Helper.findCard(card, binder.getCard());
                                if (ownCard!= null){
                                    System.out.println("Please input details of incoming card");
                                    Cards incomingCard = Helper.generateCard(sc);
                                    if (incomingCard != null){
                                       int cardIndex = Helper.findIndex(ownCard, binder.getCard());
                                        binder.tradeCards(ownCard, incomingCard, cardIndex);
                                    }else{
                                        System.out.println("Trade was not successful");
                                    }
                                }else{
                                    System.out.println("Card is not found");
                                }
                                break;
                            case 5:
                                String answer;
                                boolean isDone = false;
                                do {
                                    System.out.println("Are you sure you want to delete " + binder.getName() + "?");

                                    answer = sc.nextLine();

                                    if (answer.equalsIgnoreCase("yes")) {
                                        deleteBinder(binder);
                                        System.out.println("Cards have been returned to the collection");
                                        isDone = true;
                                        binderChoice = 0;
                                        name = "EXIT";
                                    } else if (answer.equalsIgnoreCase("no")) {
                                        isDone = true;
                                    } else {
                                        System.out.println("Invalid input");
                                    }
                                } while (!isDone);
                                break;
                            case 6: 
                                binderChoice = 0;
                                name = "exit";
                                break;
                            case 0:
                                System.out.println("Exiting");
                                break;
                            default:
                                System.out.println("Invalid choice");
                        }
                    } while (binderChoice != 0);
                } else if (name.equalsIgnoreCase("exit") && binder == null) {
                    System.out.println("Binder not found");
                }
            } while (!name.equalsIgnoreCase("EXIT"));
        } else if ((userChoice == 5 && existingDeck) || userChoice == 6 && existingDeck) {
            String name;
            do {
                viewDecks();
                System.out.print("Enter deck name or EXIT to go back:");
                name = sc.nextLine();
                Decks deck = Helper.findDecks(name, decks);
                if (deck != null) {
                    int deckChoice;
                        do {
                            System.out.println("Deck: " + deck.getName());
                            System.out.println("╔══════════════════════════════╗");
                            System.out.println("║ [0] Exit                     ║");
                            System.out.println("║ [1] Add Card                 ║");
                            System.out.println("║ [2] Remove Card              ║");
                            System.out.println("║ [3] View Cards               ║");
                            System.out.println("║ [4] Delete Deck              ║");
                            System.out.println("║ [5] Return to Main Menu      ║");
                            System.out.println("╚══════════════════════════════╝");
                            System.out.print("Enter choice:");
                            deckChoice = sc.nextInt();
                            sc.nextLine();
                            switch (deckChoice) {
                                case 1:
                                    collection.displayAllCards();
                                    if (!collection.getCard().isEmpty()) {
                                        String deckCard = sc.nextLine();
                                        Cards cardToAdd = Helper.findCard(deckCard, collection.getCard());
                                        if (cardToAdd != null) {
                                            if (Helper.confirmAction()){
                                            deck.addCard(cardToAdd);
                                            }
                                        } else {
                                            System.out.println("Card is not found");
                                        }
                                    } else {
                                        System.out.println("Collection is empty");
                                    }
                                    break;

                                case 2:
                                    deck.displayDeck();
                                    if (deck.getTotalCard() > 0) {
                                        String binderCard = sc.nextLine();
                                        Cards cardToRemove = Helper.findCard(binderCard, deck.getCard());

                                        if (cardToRemove != null) {
                                            if (Helper.confirmAction()){
                                            deck.removeCard(cardToRemove);
                                            System.out.println("Card has been removed");
                                            }
                                        }else{
                                            System.out.println("Card is not found");
                                        }
                                    }
                                    break;

                                case 3:
                                    deck.displayDeck();
                                    if (!deck.getCard().isEmpty()) {
                                        String cardName;
                                        do {
                                            System.out.print("Enter card name to view details and EXIT to go back: ");
                                            cardName = sc.nextLine();
                                            Cards card = Helper.findCard(cardName, deck.getCard());
                                            if (card != null) {
                                                Helper.displayCardDetails(cardName, deck.getCard());
                                            } else if (!cardName.equalsIgnoreCase("exit")) {
                                                System.out.println("Card not found");
                                            }
                                        } while (!cardName.equalsIgnoreCase("exit"));
                                    }
                                    break;

                                case 4:
                                    String answer;
                                    boolean isDone = false;
                                    do {
                                        System.out.println("Are you sure you want to delete " + deck.getName() + "?");
                                        answer = sc.nextLine();

                                        if (answer.equalsIgnoreCase("yes")) {
                                            deleteDeck(deck);
                                            isDone = true;
                                            deckChoice = 0;
                                            name = "EXIT";
                                        } else if (answer.equalsIgnoreCase("no")) {
                                            isDone = true;
                                        } else {
                                            System.out.println("Invalid input");
                                        }
                                    } while (!isDone);
                                    break;

                                case 5:
                                    System.out.println("Returning to main menu...");
                                    deckChoice = 0;
                                    name = "exit" ;
                                    break;

                                case 0:
                                    System.out.println("Exiting");
                                    break;

                                default:
                                    System.out.println("Invalid choice");
                            }
                        }while (deckChoice != 0);
                } else if (!name.equalsIgnoreCase("exit") && deck == null) {
                    System.out.println("Deck is not found");
                }
            } while (!name.equalsIgnoreCase("EXIT"));
        } else if (userChoice == 0) {
            System.out.println("Exiting");
        } else {
            System.out.println("Invalid input");
        }
    } while (userChoice != 0);
  }
}