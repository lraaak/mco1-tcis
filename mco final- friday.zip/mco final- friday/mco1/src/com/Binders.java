package com;
import java.util.*; 
 
    public class Binders {
    private String name;
    private ArrayList<Cards> cards; 
    private static int totalBinders = 0;
    

    public Binders(String name){
        this.name = name;
        this.cards = new ArrayList<>();
        totalBinders++;
    }

    public void addCard(Cards card){
        if (this.cards.size() < 20){
            this.cards.add(card);
            Collection.removeCard(card.getName());
            System.out.println("Card added to binder: " + card.getName());
        }
        else {
            System.out.println("Binder is full");
        }
    }

    public void removeCard(Cards card){ 
           if (!this.cards.isEmpty()){
            this.cards.remove(card);
            Collection.addCard(card.getName(),card.getRarity(),card.getVariant(),card.getBaseValue());
            System.out.println("Card removed from binder: " + card.getName());
        }
        else {
            System.out.println("Card is not found in the binder or binder is empty");
        }
    }

    
 
    // assume that it is already valid trade
    // add to collection first
    // compare the cards with prompt if difference is greater than or equal to 1
    // if the card's value difference is greater a message should be shown.
    // if yes, add to outgoing card's position in the binder and delete the outgoing card from user
    // if no, remove card from collection (delete from possestsion) and return to the binder
    public void tradeCards(Cards ownCard, Cards otherCard, int ownCardIndex) {
        
        Collection.addCard(otherCard.getName(), otherCard.getRarity(), otherCard.getVariant(), otherCard.getBaseValue());

        double valueDifference = Math.abs(ownCard.getFinalValue() - otherCard.getFinalValue());

        String response;
        Scanner sc = new Scanner(System.in);
    do {
        if (valueDifference >= 1.0) {
            System.out.println("The value difference between the two cards is $" + valueDifference + ".");
        }
        System.out.print("Do you want to proceed with the trade? (yes/no): ");
        
        response = sc.nextLine().toLowerCase();
    } while (!response.equalsIgnoreCase("yes") && !response.equalsIgnoreCase("no"));


        if ("no".equalsIgnoreCase(response)) {
            System.out.println("Trade cancelled.");
            Collection.removeCard(otherCard.getName());
            return;  
        }
    
    this.cards.set(ownCardIndex, otherCard);
    Collection.removeCard(otherCard.getName());
    System.out.println("Trade successful! " + ownCard.getName() + " has been traded for " + otherCard.getName() + ".");
    System.out.println("Your new card in the binder: " + otherCard.getName());
    }

    public static void decreaseBinderCount() {
        totalBinders--;
    }

    public void displayBinder() {
        if (cards.isEmpty()){
            System.out.println("Binder is empty");
        } else {
            Helper.displayAlphabeticallyNoCount(cards);
        }
        }


    
    public String getName() {
        return name;
    }

    public ArrayList<Cards> getCard() {
        return cards;
    }
    
    public static int getTotalBinders() {
        return totalBinders;
    }

    // can remove
    public boolean checkBinder(Binders otherBinder){
        return this == otherBinder;
    }
}